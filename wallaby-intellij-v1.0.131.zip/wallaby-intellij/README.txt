To install the downloaded ZIP or the unzipped JAR (lib/wallaby-intellij.jar), please follow the instructions described here:
http://wallabyjs.com/docs/intro/install.html